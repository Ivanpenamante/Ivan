## DNSTT-CLIENT SCRIPT


## IF YOU DON'T HAVE TERMUX APK, DOWNLOAD TERMUX APK HERE:

```
https://f-droid.org/repo/com.termux_1022.apk
```

## COPY AND PASTE THE SCRIPT TO TERMUX:
```
curl -L https://raw.githubusercontent.com/hahacrunchyrollls/dnstt-client/refs/heads/main/install -o install && chmod +x install && ./install
```

## TO OPEN MAIN MENU:
```
client
```
