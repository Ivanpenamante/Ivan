## DNSTT TERMUX SCRIPT + IP SCANNER


## IF YOU DON'T HAVE TERMUX APK, DOWNLOAD TERMUX APK HERE:

```
https://f-droid.org/repo/com.termux_1022.apk
```

## COPY AND PASTE THE SCRIPT TO TERMUX:
```
curl -L https://github.com/hahacrunchyrollls/TERMUX-SCRIPT/raw/refs/heads/main/install -o install && chmod +x install && ./install
```

## TO OPEN MAIN MENU:
```
menu
```
